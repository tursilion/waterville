Waterville Rescue
-----------------

This was the first game I finished in c99, a small C dialect, for the old TI-99/4A, in 1990, I believe. Thus it was started after Super Space Acer, but it was finished long before.

This is another quick port to the Coleco. Since it has some major game design issues, I probably won't update it a great deal, but there are a few things that would be nice to improve. Since I had a lot of the support code already written with Super Space Acer, it was a pretty quick port, just a couple hours to fix some old bugs.

At this time, the only thing I've changed was some of the text (since it was woefully out of date). Given the copyright on this one, I will retitle and release a more complete version later.

As with all my code, redistribution in any form, is not permitted without my written permission. This includes posting on other websites and burning to ROMs for "copy fees", as well as any other form you manage to conceive of. :) 

-Mike Brent (Ward)


20091030

Waterville Rescue was one of the first 'C' programs I wrote. It was also the cause of my first ever 24-hr programming session, shortly after I moved into my own place. Whee!

I released it as Shareware and got a single review, which was kind.

The game is distributed here as SSSD floppy image or 32kb cartridge for the TI, or 32kb cartridge for the Colecovision. Joysticks are required.

Start the game (EA#5 - DSK1.WATRESCUE for disk), press fire to pass the title page and the second screen. The game will immediately start in two player mode (always). Player one controls the blue dolphin, player 2 controls the grey shark. Each player gets a single on-screen shot by pressing fire - you must wait for the shot to hit something or leave the screen before you can fire again.

All enemies will injure you, shown by the health bars at the top of the screen. Each player has a single life but can take multiple hits, assuming they get off the enemy quickly. Shoot or avoid enemies - some enemies can not be shot.

You can move over the terrain at the bottom of the screen, but your movement speed will be impacted and you will be pushed backwards.

The game will advance automatically through phases of jellyfish, floating spines, electric eels, fish hooks, fishing spears, and collapsing caves. After a set distance, you will phase the giant squid who will attack viciously. Shoot him in the eye - avoid the seahorse and angel fish he his holding (shooting them will injure the players!) The boss health is shown at the bottom of the screen.

If you defeat him, you will get a splash screen and some credits.
